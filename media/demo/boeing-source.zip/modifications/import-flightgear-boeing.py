"""Import public GPL FlightGear AC3D exterior; retain UVs and source attribution.
Run with Blender --background --python scripts/import-flightgear-boeing.py.
"""
import bpy, re, shlex, json, math
from pathlib import Path
from mathutils import Matrix,Vector
ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'.tmp/open-models/boeing/Models'
FILES=['737-800','LWing','RWing','VertStab','HorzStab','winglet2']
bpy.ops.wm.read_factory_settings(use_empty=True)
materials={};images={};stats={}
# AC3D coordinates are right-handed Y-up; rotate into Blender's Z-up world.
C=Matrix.Rotation(math.pi,4,'Z')@Matrix(((1,0,0,0),(0,0,-1,0),(0,1,0,0),(0,0,0,1)))

def material(src,index,texture):
 key=('texture',texture) if texture else tuple(src[src.index('rgb'):])
 if key in materials:return materials[key]
 m=bpy.data.materials.new('FlightGear_'+str(len(materials)));m.use_nodes=True
 bs=m.node_tree.nodes.get('Principled BSDF')
 rgb=src[src.index('rgb')+1:src.index('rgb')+4];alpha=1-float(src[src.index('trans')+1])
 bs.inputs['Base Color'].default_value=tuple(map(float,rgb))+(alpha,)
 bs.inputs['Roughness'].default_value=.38 if texture else .47
 bs.inputs['Metallic'].default_value=.12
 if texture:
  path=(ROOT/'.tmp/open-models/livery/737-800/SEJ.png') if texture=='737-800.png' else SOURCE/texture
  if not path.exists():raise RuntimeError('Missing texture '+str(path))
  if str(path) not in images:images[str(path)]=bpy.data.images.load(str(path))
  tex=m.node_tree.nodes.new('ShaderNodeTexImage');tex.image=images[str(path)]
  m.node_tree.links.new(tex.outputs['Color'],bs.inputs['Base Color'])
  # Painted airframe texture is opaque. Glass is assigned separately by name.
 if alpha<.99:
  bs.inputs['Alpha'].default_value=alpha
  m.surface_render_method='DITHERED'
 materials[key]=m;return m

def parse_file(name):
 lines=(SOURCE/(name+'.ac')).read_text().splitlines();pos=1;palette=[];objects=[]
 while pos<len(lines) and lines[pos].startswith('MATERIAL'):
  palette.append(shlex.split(lines[pos]));pos+=1
 def read(parent=None):
  nonlocal pos
  typ=lines[pos].split()[1];pos+=1
  objname=name;texture=None;verts=[];faces=[];uvs=[];mats=[];flags=[];loc=(0,0,0);rot=Matrix.Identity(3)
  while pos<len(lines):
   fields=shlex.split(lines[pos]);pos+=1
   if not fields:continue
   key=fields[0]
   if key=='name':objname=fields[1]
   elif key=='texture':texture=fields[1]
   elif key=='loc':loc=tuple(map(float,fields[1:4]))
   elif key=='rot':rot=Matrix([list(map(float,fields[1+i*3:4+i*3])) for i in range(3)])
   elif key=='data':pos+=1
   elif key=='numvert':
    for _ in range(int(fields[1])):verts.append(tuple(map(float,lines[pos].split())));pos+=1
   elif key=='numsurf':
    for _ in range(int(fields[1])):
     flag=int(lines[pos].split()[1],0);pos+=1
     mi=0
     if lines[pos].startswith('mat '):mi=int(lines[pos].split()[1]);pos+=1
     count=int(lines[pos].split()[1]);pos+=1;refs=[];faceuv=[]
     for _ in range(count):
      ref=lines[pos].split();pos+=1;refs.append(int(ref[0]));faceuv.append(tuple(map(float,ref[1:3])))
     if len(refs)>=3 and flag&0xf==0:faces.append(refs);uvs.append(faceuv);mats.append(mi);flags.append(flag)
   elif key=='kids':
    obj=bpy.data.objects.new('FG_'+objname,None) if not faces else None
    if faces:
     mesh=bpy.data.meshes.new(objname);mesh.from_pydata(verts,[],faces);mesh.update()
     obj=bpy.data.objects.new('FG_'+objname,mesh)
     for i,p in enumerate(palette):mesh.materials.append(material(p,i,texture))
     uv=mesh.uv_layers.new(name='SourceUV')
     for i,poly in enumerate(mesh.polygons):
      poly.material_index=mats[i];poly.use_smooth=bool(flags[i]&0x10)
      for li,coord in zip(poly.loop_indices,uvs[i]):uv.data[li].uv=coord
     # Source windows contain separate glazing; tint them rather than show a white sheet.
     if 'windows.ext' in objname or 'rearwindows.ext' in objname:
      glass=bpy.data.materials.get('FlightGear cockpit glazing')
      if not glass:
       glass=bpy.data.materials.new('FlightGear cockpit glazing');glass.use_nodes=True;b=glass.node_tree.nodes.get('Principled BSDF');b.inputs['Base Color'].default_value=(.018,.035,.045,1);b.inputs['Metallic'].default_value=.45;b.inputs['Roughness'].default_value=.17
      mesh.materials.clear();mesh.materials.append(glass)
    bpy.context.collection.objects.link(obj);obj.parent=parent
    obj.matrix_local=Matrix.Translation(Vector(loc))@rot.to_4x4()
    objects.append(obj)
    for _ in range(int(fields[1])):read(obj)
    return obj
 root=read();root.matrix_world=C@root.matrix_world
 bpy.context.view_layer.update()
 stats[name]={'objects':len(objects),'faces':sum(len(o.data.polygons) for o in objects if o.type=='MESH')}
 return objects
allobjs=[]
for f in FILES:allobjs+=parse_file(f)
# Model default is gear down. Exclude the gear assemblies; retain closed fuselage doors.
remove=set()
for o in allobjs:
 n=o.name.lower()
 if any(x in n for x in ['mainwheel','mainstrut','maingear','nosegear','nosewheel','hydraulic','gearscissor','landinggear','mgouter','mgrh','mglh','strut','bearing','tires','lhgd','rhgd','geardoor']):
  remove.add(o);remove.update(o.children_recursive)
for o in remove:bpy.data.objects.remove(o,do_unlink=True)
# The supplied split-winglet file has two variants; retain the blended upper pair.
for o in list(bpy.context.scene.objects):
 if o.type=='MESH' and ('winglet.001' in o.name):bpy.data.objects.remove(o,do_unlink=True)
# Only export renderable exterior objects and merge by material for bounded draw calls.
bpy.context.view_layer.update()
from collections import defaultdict
groups=defaultdict(list)
for o in list(bpy.context.scene.objects):
 if o.type=='MESH':
  # Bake transforms first so root axis conversions survive joining.
  world=o.matrix_world.copy();o.parent=None;o.data.transform(world);o.matrix_world=Matrix.Identity(4)
  groups[tuple(m.name for m in o.data.materials)].append(o)
for k,objs in groups.items():
 bpy.ops.object.select_all(action='DESELECT')
 for o in objs:o.select_set(True)
 bpy.context.view_layer.objects.active=objs[0]
 if len(objs)>1:bpy.ops.object.join()
 bpy.context.object.name='Boeing_Exterior_'+str(len(k))+'_'+str(len(objs))
for o in list(bpy.context.scene.objects):
 if o.type=='EMPTY':bpy.data.objects.remove(o,do_unlink=True)
# Remove unused slots to avoid duplicating primitives per identical source palette entry.
for o in bpy.context.scene.objects:
 if o.type=='MESH':
  bpy.context.view_layer.objects.active=o
  bpy.ops.object.material_slot_remove_unused()
  o.data.validate()
out=ROOT/'scene/assets/civil-flightgear.glb';out.parent.mkdir(exist_ok=True,parents=True)
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'artifacts/model-sources/civil-flightgear.blend'))
bpy.ops.export_scene.gltf(filepath=str(out),export_format='GLB',export_extras=True)
print('FLIGHTGEAR_SOURCE_REPORT',json.dumps(stats),'meshes',sum(o.type=='MESH' for o in bpy.context.scene.objects))
