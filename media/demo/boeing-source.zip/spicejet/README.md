# FG-liveries
Liveries for FlightGear

If you have suggestions for more liveries write to me on FG forum or FG discord or via email - pilot.2938@gmail.com

# Liveries you can find:

## Airbus:
# Note to A320: currently under reworking for new 3D model
#### A320-214:
Air Canada, Austrian Airlines, British Airways, Condor, Eurowings, Swiss, TAP Air Portugal

#### A320-232:
British Airways, Qatar, Air Seychelles, Pan Pacific Airlines

#### A320-251N:
British Airways, TAP Air Portugal, Air Seychelles

#### A320-271N:
Swiss, Wizz Air, Qatar

#### A330-203:
Eurowings

#### A330-243:
Air Seychelles, Air China, Capital Airlines

#### A330-343:
Eurowings, Hainan Airlines, Capital Airlines

#### A350-900:
Lufthansa, Cathay Pacific, SAS Scandinavian Airlines, Japan Airlines, South African, Asiana

#### A380:
Asiana Airlines, Lufthansa, Korean Air, Qatar, ANA, Thai Airways

#### EC135:

Polish Border Guard, Lotnicze Pogotowie Ratunkowe

## Boeing:

#### Boeing 707:
Sabena, British Midland, Varig, British Airways, Qantas, American Airlines

#### Boeing 737-800:
LOT, TUI Airways, Polish Air Force, US-Bangla, SpiceJet

#### Boeing 747-8i:
Qatar

#### Boeing 747-8F: 
UPS

#### Boeing 757-200: 
Icelandair, TUI Airways, Easyjet, Delta, United, Continental, Finnair, British Airways, American Airlines

#### Boeing 757-300:
Condor, Icelandair

#### Boeing 787-8:
American Airlines, Air Canada, LOT, TUI Airways, LATAM Chile, British Airways, Biman Bangladesh

#### Boeing 787-9:
America Airlines, Air Canada, KLM, LOT, Qantas, TUI Airways, Virgin Atlantic, LATAM chile, British Airways, Turkish Airways, Biman Bangladesh, Air China, Korean Air, ANA

#### Boeing 777-300:
Air India, Biman Bangladesh

## DHC:

#### DHC-6:
Air Seychelles

## Embraer:

#### Embraer E170:
LOT

#### Embraer E175:
LOT

#### Embraer E190:
Ukrainian Airlines

#### Embraer E195:
Ukrainian Airlines, LOT 

#### Lineage 1000:
Air X

## McDonnell Douglas:

#### MD-11:
American Airlines, Alitalia, Japan Airlines, China Eastern, CityBird, Finnair, Delta, Sabena, KLM, Swiss, Aer Lingus, Air Namibia, World Airways, Korean Air

#### MD-11F:
Alitalia, China Eastern, EVA Air Cargo, Aeroflot, Finnair, AV Cargo, World Airways, Western Global Airlines, Lufthansa, Korean Air Cargo, Martinair Cargo

#### MD-80:
Delta, SAS Scandinavian Airlines

## Bombardier:

#### Bombardier Dash8 Q400:
US-Bangla, Biman Bangladesh, SpiceJet

# In progress:

MD-11: some liveries

787-9: Vistara

E-jet: Kenya Airways

### Make sure to check out https://herbert394.wixsite.com/fgliveries for even more high quality livs!
